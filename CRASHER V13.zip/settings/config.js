global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['6285659339758']
global.packname = "Crasher"
global.author = "Crasher"
global.mess = {
 owner: '*BUKAN OWNER BEGO 🥱*',
 premium: '*BUKAN PREM BEGO 🥱*'
}